﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PharmacyMS
{
    class Medicine
    {

        public string mid { get; set; }
        public string mname { get; set; }
        public string number { get; set; }
        public Int64 quantity { get; set; }
        public string mdate { get; set; }
        public string edate { get; set; }
        public Int64 price { get; set; }


    }
}
